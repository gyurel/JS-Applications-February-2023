import { cleanViews } from "./utils.js";
import { showHome } from "./homeView.js";


cleanViews();
showHome();