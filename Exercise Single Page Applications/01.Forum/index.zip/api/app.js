import { showHome } from "./home.js";
// import { showComments } from "./comments.js";

const showHomeLink = document.getElementById('homeLink').addEventListener('click', showHome);



showHome();


